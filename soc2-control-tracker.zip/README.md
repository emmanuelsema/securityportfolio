# SOC 2 Control Tracker

This project automates the validation of SOC 2 controls using AWS APIs (Boto3).
It checks for:
- IAM user access key rotation
- MFA enabled for all users
- CloudTrail logging enabled
- S3 bucket encryption

Run this script regularly or integrate it into your CI/CD for continuous monitoring.
