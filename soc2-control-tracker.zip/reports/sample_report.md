# Sample SOC 2 Compliance Report

## IAM Users
- user1: MFA Enabled
- user2: MFA Not Enabled

## S3 Buckets
- logs-bucket: Encryption Enabled
- public-bucket: Encryption Not Enabled

## CloudTrail
- trail-1: S3BucketName: audit-logs-bucket