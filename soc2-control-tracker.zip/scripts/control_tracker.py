import boto3

def check_iam_users():
    iam = boto3.client('iam')
    users = iam.list_users()['Users']
    for user in users:
        mfa = iam.list_mfa_devices(UserName=user['UserName'])['MFADevices']
        print(f"User: {user['UserName']}, MFA Enabled: {'Yes' if mfa else 'No'}")

def check_s3_encryption():
    s3 = boto3.client('s3')
    buckets = s3.list_buckets()['Buckets']
    for bucket in buckets:
        try:
            enc = s3.get_bucket_encryption(Bucket=bucket['Name'])
            rules = enc['ServerSideEncryptionConfiguration']['Rules']
            print(f"Bucket: {bucket['Name']} - Encryption Enabled")
        except Exception:
            print(f"Bucket: {bucket['Name']} - Encryption Not Enabled")

def check_cloudtrail():
    ct = boto3.client('cloudtrail')
    trails = ct.describe_trails()['trailList']
    for trail in trails:
        print(f"Trail: {trail['Name']} - S3 Bucket: {trail['S3BucketName']}")

if __name__ == "__main__":
    print("Checking IAM Users for MFA...")
    check_iam_users()
    print("\nChecking S3 Buckets for Encryption...")
    check_s3_encryption()
    print("\nChecking CloudTrail Configuration...")
    check_cloudtrail()
