# SOC 2 Mapping

This document explains how each Terraform module aligns with SOC 2 Trust Service Criteria.

## Example
- **CloudTrail** → Satisfies Audit Logging requirement (CC7.2, CC7.3)
- **S3 Encryption** → Data at rest encryption (CC6.1)
