# AWS Secure Baseline

Terraform modules for building a secure AWS environment.

This project includes:
- Encrypted S3 Buckets
- Least Privilege IAM Roles
- CloudTrail Configuration
- GuardDuty Enablement

Each module is designed to be audit-ready and SOC 2 compliant.
